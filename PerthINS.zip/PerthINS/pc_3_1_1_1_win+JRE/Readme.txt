Payment Client 3.1.1.1 Readme
-----------------------------

The Payment Client installation package is provided in the root directory of the
extracted zip file downloaded or provided by your Payment Service Provider.

A pre-requisite for the Payment Client install is to have installed a compatible
Sun Microsystems distribution of the Java Runtime Environment (version 1.4.x).
To assist with this, an installer for a compatible Java Runtime Environment is
included in the 'java' subdirectory of the extracted zip file downloaded or
provided by your Payment Service Provide. If a compatible Java Runtime
Environment is not already installed, it must be installed before attempting to
install the Payment Client.

For more information on Payment Client compatibility please refer to the Payment
Client documentation.
