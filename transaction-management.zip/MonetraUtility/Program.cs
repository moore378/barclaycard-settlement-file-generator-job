﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;



namespace MonetraUtility
{
    class Program
    {

        static void log(string message)
        {
            Console.WriteLine(message);
        }

        static void Main(string[] args)
        {
            string server = "db5";
            ushort port = 8666;
            string file = "data.txt";

            MonetraUtility mu = new MonetraUtility(server, port, "madmin", "madmin123");

            string[] merchants = File.ReadAllLines(file);

            mu.ProcessIndustryCode(merchants, "rs");
        }
    }
}
