﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Reflection;

using MjhGeneral;
using AuthorizationClientPlatforms;

namespace MonetraUtility
{
    public class MonetraUtility : MonetraDotNetNativeClient
    {
        private string admin;
        private string pass;

        public MonetraUtility(string server, ushort port, string admin, string pass)
            : base(server, port, (log) => { Console.WriteLine(log); })
        {
            // Call parent constructor.

            // Save off the admin credentials.
            this.admin = admin;
            this.pass = pass;
        }

        public void ProcessIndustryCode(string[] merchants, string industryCode)
        {
            foreach(string entry in merchants)
            {
                Transaction.Response response = ProcessIndustryCode(entry, industryCode);

                // If success continue.
                if (Transaction.Response.Status.M_SUCCESS == response.ReturnStatus)
                {
                    // Verify that it was changed correctly.
                    string key = QueryIndustryCode(entry);
                }
            }
        }

        public Transaction.Response ProcessIndustryCode(string merchant, string industryCode)
        {
            TransactionWrapper transaction = (TransactionWrapper)newTransaction();

            monetra.TransKeyVal(transaction.transactionID, "username", admin);
            monetra.TransKeyVal(transaction.transactionID, "password", pass);
            monetra.TransKeyVal(transaction.transactionID, "action", "edituser");

            monetra.TransKeyVal(transaction.transactionID, "user", merchant);
            monetra.TransKeyVal(transaction.transactionID, "indcode", industryCode);

            Transaction.Response response = transaction.send();

            return response;
        }

        public string QueryIndustryCode(string merchant)
        {
            string code = "";

            TransactionWrapper transaction = (TransactionWrapper)newTransaction();

            monetra.TransKeyVal(transaction.transactionID, "username", admin);
            monetra.TransKeyVal(transaction.transactionID, "password", pass);
            monetra.TransKeyVal(transaction.transactionID, "action", "getuserinfo");

            monetra.TransKeyVal(transaction.transactionID, "user", merchant);

            Transaction.Response response = transaction.send();

            if (Transaction.Response.Status.M_SUCCESS == response.ReturnStatus)
            {
                string keys = response.AllResponseKeys("\n");

                string pair = keys.Split(new char[] { '\n' }).Single(t => t.StartsWith("INDCODE"));

                code = pair.Substring(pair.IndexOf("=") + 1);
            }

            return code;
        }
    }
}
