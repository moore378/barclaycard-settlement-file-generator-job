﻿namespace CctmForBlacklisted
{
    partial class CctmForBlacklistedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CctmForBlacklistedForm));
            this.RunButton = new System.Windows.Forms.Button();
            this.dataSet1 = new CctmForBlacklisted.DataSet1();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter = new CctmForBlacklisted.DataSet1TableAdapters.SEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter();
            this.tableAdapterManager = new CctmForBlacklisted.DataSet1TableAdapters.TableAdapterManager();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.splitTransactionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.splitTransactionsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator)).BeginInit();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitTransactionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitTransactionsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // RunButton
            // 
            this.RunButton.Location = new System.Drawing.Point(928, 28);
            this.RunButton.Name = "RunButton";
            this.RunButton.Size = new System.Drawing.Size(75, 23);
            this.RunButton.TabIndex = 0;
            this.RunButton.Text = "Run";
            this.RunButton.UseVisualStyleBackColor = true;
            this.RunButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource
            // 
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource.DataMember = "SEL_DECLINED_TRANSACTIONRECORDS_CCTM";
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource.DataSource = this.dataSet1;
            // 
            // sEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter
            // 
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = CctmForBlacklisted.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator
            // 
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.BindingSource = this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem});
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.Name = "sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator";
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.Size = new System.Drawing.Size(1015, 25);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.TabIndex = 1;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem
            // 
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Enabled = false;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Image")));
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Name = "sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem";
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView
            // 
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.AutoGenerateColumns = false;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26});
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.DataSource = this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource;
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.Location = new System.Drawing.Point(12, 57);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.Name = "sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView";
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.Size = new System.Drawing.Size(298, 454);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TransactionRecordID";
            this.dataGridViewTextBoxColumn1.HeaderText = "TransactionRecordID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PoleID";
            this.dataGridViewTextBoxColumn2.HeaderText = "PoleID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TerminalID";
            this.dataGridViewTextBoxColumn3.HeaderText = "TerminalID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "StartDateTime";
            this.dataGridViewTextBoxColumn4.HeaderText = "StartDateTime";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TotalCredit";
            this.dataGridViewTextBoxColumn5.HeaderText = "TotalCredit";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "TimePurchased";
            this.dataGridViewTextBoxColumn6.HeaderText = "TimePurchased";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "TotalParkingTime";
            this.dataGridViewTextBoxColumn7.HeaderText = "TotalParkingTime";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CCAmount";
            this.dataGridViewTextBoxColumn8.HeaderText = "CCAmount";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "CCTracks";
            this.dataGridViewTextBoxColumn9.HeaderText = "CCTracks";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CCTransactionStatus";
            this.dataGridViewTextBoxColumn10.HeaderText = "CCTransactionStatus";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "CCTransactionIndex";
            this.dataGridViewTextBoxColumn11.HeaderText = "CCTransactionIndex";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "EncryptionVer";
            this.dataGridViewTextBoxColumn12.HeaderText = "EncryptionVer";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "KeyVer";
            this.dataGridViewTextBoxColumn13.HeaderText = "KeyVer";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "UniqueRecordNumber";
            this.dataGridViewTextBoxColumn14.HeaderText = "UniqueRecordNumber";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "DateTimeCreated";
            this.dataGridViewTextBoxColumn15.HeaderText = "DateTimeCreated";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "DateTimeModified";
            this.dataGridViewTextBoxColumn16.HeaderText = "DateTimeModified";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "TerminalSerNo";
            this.dataGridViewTextBoxColumn17.HeaderText = "TerminalSerNo";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "MeterTransactionStatus";
            this.dataGridViewTextBoxColumn18.HeaderText = "MeterTransactionStatus";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "CreditCallCardEaseReference";
            this.dataGridViewTextBoxColumn19.HeaderText = "CreditCallCardEaseReference";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "CreditCallAuthCode";
            this.dataGridViewTextBoxColumn20.HeaderText = "CreditCallAuthCode";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "CreditCallPAN";
            this.dataGridViewTextBoxColumn21.HeaderText = "CreditCallPAN";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "CreditCallExpiryDate";
            this.dataGridViewTextBoxColumn22.HeaderText = "CreditCallExpiryDate";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "CreditCallCardScheme";
            this.dataGridViewTextBoxColumn23.HeaderText = "CreditCallCardScheme";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "CCFirstSix";
            this.dataGridViewTextBoxColumn24.HeaderText = "CCFirstSix";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "CCLastFour";
            this.dataGridViewTextBoxColumn25.HeaderText = "CCLastFour";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "CCExpiryDate";
            this.dataGridViewTextBoxColumn26.HeaderText = "CCExpiryDate";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // splitTransactionsBindingSource
            // 
            this.splitTransactionsBindingSource.DataMember = "SplitTransactions";
            this.splitTransactionsBindingSource.DataSource = this.dataSet1;
            // 
            // splitTransactionsDataGridView
            // 
            this.splitTransactionsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitTransactionsDataGridView.AutoGenerateColumns = false;
            this.splitTransactionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.splitTransactionsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30});
            this.splitTransactionsDataGridView.DataSource = this.splitTransactionsBindingSource;
            this.splitTransactionsDataGridView.Location = new System.Drawing.Point(316, 57);
            this.splitTransactionsDataGridView.Name = "splitTransactionsDataGridView";
            this.splitTransactionsDataGridView.Size = new System.Drawing.Size(687, 454);
            this.splitTransactionsDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "FirstSix";
            this.dataGridViewTextBoxColumn27.HeaderText = "FirstSix";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "LastFour";
            this.dataGridViewTextBoxColumn28.HeaderText = "LastFour";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Expiry";
            this.dataGridViewTextBoxColumn29.HeaderText = "Expiry";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Hash";
            this.dataGridViewTextBoxColumn30.HeaderText = "Hash";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(157, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Index Upd";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // CctmForBlacklistedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 523);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.splitTransactionsDataGridView);
            this.Controls.Add(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView);
            this.Controls.Add(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator);
            this.Controls.Add(this.RunButton);
            this.Name = "CctmForBlacklistedForm";
            this.Text = "CCTM for blacklisted transactions";
            this.Load += new System.EventHandler(this.CctmForBlacklistedForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator)).EndInit();
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.ResumeLayout(false);
            this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitTransactionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitTransactionsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RunButton;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingSource;
        private DataSet1TableAdapters.SEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter sEL_DECLINED_TRANSACTIONRECORDS_CCTMTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton sEL_DECLINED_TRANSACTIONRECORDS_CCTMBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView sEL_DECLINED_TRANSACTIONRECORDS_CCTMDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.BindingSource splitTransactionsBindingSource;
        private System.Windows.Forms.DataGridView splitTransactionsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.Button button1;
    }
}

