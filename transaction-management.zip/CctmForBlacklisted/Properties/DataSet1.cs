﻿namespace CctmForBlacklisted {
    
    
    public partial class DataSet1 {
        partial class TransactionFixesDataTable
        {
        }
    }
}
