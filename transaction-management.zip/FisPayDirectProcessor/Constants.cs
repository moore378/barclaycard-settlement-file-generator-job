﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FisPayDirectProcessor
{
    public static class Constants
    {
        public const string SERVICE_NAME = "IPS Processor FIS PayDirect";
    }
}
